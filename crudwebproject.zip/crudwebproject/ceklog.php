<?php 

if(isset($_SESSION['loglog'])){

}else{
    header('location:login.php');
}
